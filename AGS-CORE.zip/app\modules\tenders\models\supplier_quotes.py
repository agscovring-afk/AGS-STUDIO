class SupplierQuotes:

    pass
