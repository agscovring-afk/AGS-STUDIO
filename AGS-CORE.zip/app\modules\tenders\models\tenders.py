class Tenders:

    pass
