class TenderDocuments:

    pass
