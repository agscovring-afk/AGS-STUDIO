class BoqItems:

    pass
