class EmployeeService:
    pass
