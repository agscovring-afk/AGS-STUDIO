class TenderEvaluations:

    pass
